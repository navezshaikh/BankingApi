package com.bank.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.models.Users;
import com.bank.services.BankServices;

@RestController
@RequestMapping("/bank")
public class BankController {
	
	@Autowired
	BankServices bankServices;
	
	@PostMapping
    public Users createAccount(@RequestBody Users account) {
        return bankServices.createAccount(account);
    }

    @GetMapping("/{id}")
    public Users getAccount(@PathVariable Long id) {
        return bankServices.getAccount(id).orElseThrow(() -> new RuntimeException("Account not found"));
    }

    @PostMapping("/{id}/deposit")
    public Users deposit(@PathVariable Long id, @RequestBody Map<String, Double> request) {
        Double amount = request.get("amount");
        return bankServices.deposit(id, amount);
    }

    @PostMapping("/{id}/withdraw")
    public Users withdraw(@PathVariable Long id, @RequestBody Map<String, Double> request) {
        Double amount = request.get("amount");
        return bankServices.withdraw(id, amount);
    }


}
