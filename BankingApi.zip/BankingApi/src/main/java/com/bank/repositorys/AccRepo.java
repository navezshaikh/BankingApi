package com.bank.repositorys;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bank.models.Users;

public interface AccRepo extends JpaRepository<Users, Long> {

}
