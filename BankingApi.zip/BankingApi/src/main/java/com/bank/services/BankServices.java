package com.bank.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.models.Users;
import com.bank.repositorys.AccRepo;

@Service
public class BankServices {
	
	@Autowired
    private AccRepo AccRepo;

    public Users createAccount(Users user) {
        return AccRepo.save(user);
    }

    public Optional<Users> getAccount(Long id) {
        return AccRepo.findById(id);
    }

    public Users deposit(Long id, double amount) {
    	Users account = getAccount(id).orElseThrow(() -> new RuntimeException("Account not found"));
    	account.setBalance(account.getBalance() + amount);
        return AccRepo.save(account);
    }

    public Users withdraw(Long id, double amount) {
    	Users account = getAccount(id).orElseThrow(() -> new RuntimeException("Account not found"));
        if (account.getBalance() < amount) {
            throw new RuntimeException("Insufficient funds");
        }
        account.setBalance(account.getBalance() - amount);
        return AccRepo.save(account);
    }

}
